--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.2
-- Dumped by pg_dump version 11.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE detognieli;
--
-- Name: detognieli; Type: DATABASE; Schema: -; Owner: detognieli
--

CREATE DATABASE detognieli WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE detognieli OWNER TO detognieli;

\connect detognieli

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: progetto; Type: SCHEMA; Schema: -; Owner: detognieli
--

CREATE SCHEMA progetto;


ALTER SCHEMA progetto OWNER TO detognieli;

--
-- Name: livelli_corso; Type: DOMAIN; Schema: public; Owner: detognieli
--

CREATE DOMAIN public.livelli_corso AS integer
	CONSTRAINT livelli_corso_check CHECK (((VALUE >= 0) AND (VALUE <= 3)));


ALTER DOMAIN public.livelli_corso OWNER TO detognieli;

--
-- Name: mod_conoscenza_scuola; Type: DOMAIN; Schema: public; Owner: detognieli
--

CREATE DOMAIN public.mod_conoscenza_scuola AS character varying(16)
	CONSTRAINT mod_conoscenza_scuola_check CHECK ((((VALUE)::text = 'Volantini'::text) OR ((VALUE)::text = 'Facebook'::text) OR ((VALUE)::text = 'Instagram'::text) OR (VALUE IS NULL)));


ALTER DOMAIN public.mod_conoscenza_scuola OWNER TO detognieli;

--
-- Name: tipo_capo; Type: DOMAIN; Schema: public; Owner: detognieli
--

CREATE DOMAIN public.tipo_capo AS character varying(24)
	CONSTRAINT tipo_capo_check CHECK ((((VALUE)::text = 'Maglietta'::text) OR ((VALUE)::text = 'Pantalone'::text) OR ((VALUE)::text = 'Felpa'::text) OR ((VALUE)::text = 'Pantaloncini'::text) OR ((VALUE)::text = 'Cappello'::text) OR (VALUE IS NULL)));


ALTER DOMAIN public.tipo_capo OWNER TO detognieli;

--
-- Name: tipo_oggetto; Type: DOMAIN; Schema: public; Owner: detognieli
--

CREATE DOMAIN public.tipo_oggetto AS character varying(24)
	CONSTRAINT tipo_oggetto_check CHECK ((((VALUE)::text = 'Capo'::text) OR ((VALUE)::text = 'Biglietto'::text) OR ((VALUE)::text = 'Dvd'::text)));


ALTER DOMAIN public.tipo_oggetto OWNER TO detognieli;

--
-- Name: tipo_pagamento; Type: DOMAIN; Schema: public; Owner: detognieli
--

CREATE DOMAIN public.tipo_pagamento AS character varying(16)
	CONSTRAINT tipo_pagamento_check CHECK ((((VALUE)::text = 'Oggetto'::text) OR ((VALUE)::text = 'Corso'::text) OR ((VALUE)::text = 'Tessera'::text) OR ((VALUE)::text = 'Annuale'::text)));


ALTER DOMAIN public.tipo_pagamento OWNER TO detognieli;

--
-- Name: tipo_socio; Type: DOMAIN; Schema: public; Owner: detognieli
--

CREATE DOMAIN public.tipo_socio AS character varying(16)
	CONSTRAINT tipo_socio_check CHECK ((((VALUE)::text = 'Studente'::text) OR ((VALUE)::text = 'Insegnante'::text)));


ALTER DOMAIN public.tipo_socio OWNER TO detognieli;

--
-- Name: tipologia_tessera; Type: DOMAIN; Schema: public; Owner: detognieli
--

CREATE DOMAIN public.tipologia_tessera AS character varying(16)
	CONSTRAINT tipologia_tessera_check CHECK ((((VALUE)::text = 'Tipologia-1'::text) OR ((VALUE)::text = 'Tipologia-2'::text) OR ((VALUE)::text = 'Tipologia-3'::text) OR ((VALUE)::text = 'Tipologia-4'::text)));


ALTER DOMAIN public.tipologia_tessera OWNER TO detognieli;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: appello; Type: TABLE; Schema: public; Owner: detognieli
--

CREATE TABLE public.appello (
    data_lezione timestamp without time zone NOT NULL,
    corso character varying(48) NOT NULL,
    anno_corso integer NOT NULL,
    presente boolean NOT NULL,
    socio character(16) NOT NULL,
    anno_socio integer NOT NULL
);


ALTER TABLE public.appello OWNER TO detognieli;

--
-- Name: aula; Type: TABLE; Schema: public; Owner: detognieli
--

CREATE TABLE public.aula (
    numero integer NOT NULL,
    nome character varying(48),
    capienza integer NOT NULL,
    descrizione character varying(48),
    CONSTRAINT aula_capienza_check CHECK ((capienza >= 0))
);


ALTER TABLE public.aula OWNER TO detognieli;

--
-- Name: certificato_medico; Type: TABLE; Schema: public; Owner: detognieli
--

CREATE TABLE public.certificato_medico (
    socio character(16) NOT NULL,
    data_scadenza date NOT NULL
);


ALTER TABLE public.certificato_medico OWNER TO detognieli;

--
-- Name: codice_oggetto_seq; Type: SEQUENCE; Schema: public; Owner: detognieli
--

CREATE SEQUENCE public.codice_oggetto_seq
    START WITH 0
    INCREMENT BY 1
    MINVALUE 0
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.codice_oggetto_seq OWNER TO detognieli;

--
-- Name: corso; Type: TABLE; Schema: public; Owner: detognieli
--

CREATE TABLE public.corso (
    nome character varying(48) NOT NULL,
    anno integer NOT NULL,
    costo_lezione numeric(5,2) NOT NULL,
    livello public.livelli_corso NOT NULL,
    descrizione character varying(48),
    CONSTRAINT corso_anno_check CHECK ((anno >= 2016)),
    CONSTRAINT corso_costo_lezione_check CHECK ((costo_lezione >= (0)::numeric))
);


ALTER TABLE public.corso OWNER TO detognieli;

--
-- Name: garante; Type: TABLE; Schema: public; Owner: detognieli
--

CREATE TABLE public.garante (
    tutore character(16) NOT NULL,
    anno integer NOT NULL
);


ALTER TABLE public.garante OWNER TO detognieli;

--
-- Name: garante_socio; Type: TABLE; Schema: public; Owner: detognieli
--

CREATE TABLE public.garante_socio (
    tutore character(16) NOT NULL,
    anno integer NOT NULL,
    socio character(16)
);


ALTER TABLE public.garante_socio OWNER TO detognieli;

--
-- Name: insegna; Type: TABLE; Schema: public; Owner: detognieli
--

CREATE TABLE public.insegna (
    data_lezione timestamp without time zone NOT NULL,
    corso character varying(48) NOT NULL,
    anno_corso integer NOT NULL,
    socio character(16) NOT NULL,
    anno_socio integer NOT NULL
);


ALTER TABLE public.insegna OWNER TO detognieli;

--
-- Name: iscrizione_corso; Type: TABLE; Schema: public; Owner: detognieli
--

CREATE TABLE public.iscrizione_corso (
    corso character varying(48) NOT NULL,
    anno_corso integer NOT NULL,
    socio character(16) NOT NULL,
    anno_socio integer NOT NULL,
    data_iscrizione date NOT NULL
);


ALTER TABLE public.iscrizione_corso OWNER TO detognieli;

--
-- Name: lezione; Type: TABLE; Schema: public; Owner: detognieli
--

CREATE TABLE public.lezione (
    corso character varying(48) NOT NULL,
    anno_corso integer NOT NULL,
    data_lezione timestamp without time zone NOT NULL,
    aula integer NOT NULL
);


ALTER TABLE public.lezione OWNER TO detognieli;

--
-- Name: oggetto; Type: TABLE; Schema: public; Owner: detognieli
--

CREATE TABLE public.oggetto (
    codice integer DEFAULT nextval('public.codice_oggetto_seq'::regclass) NOT NULL,
    tipo public.tipo_oggetto NOT NULL,
    prezzo numeric(5,2) NOT NULL,
    descrizione character varying(64),
    tipo_capo public.tipo_capo DEFAULT NULL::character varying,
    codice_posto integer,
    anno_dvd integer,
    CONSTRAINT oggetto_anno_dvd_check CHECK (((anno_dvd >= 0) OR (anno_dvd IS NULL))),
    CONSTRAINT oggetto_codice_check CHECK ((codice >= 0)),
    CONSTRAINT oggetto_codice_posto_check CHECK (((codice_posto >= 0) OR (codice_posto IS NULL))),
    CONSTRAINT oggetto_prezzo_check CHECK ((prezzo >= (0)::numeric))
);


ALTER TABLE public.oggetto OWNER TO detognieli;

--
-- Name: progressivo_pagamento_seq; Type: SEQUENCE; Schema: public; Owner: detognieli
--

CREATE SEQUENCE public.progressivo_pagamento_seq
    START WITH 0
    INCREMENT BY 1
    MINVALUE 0
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.progressivo_pagamento_seq OWNER TO detognieli;

--
-- Name: pagamento; Type: TABLE; Schema: public; Owner: detognieli
--

CREATE TABLE public.pagamento (
    progressivo integer DEFAULT nextval('public.progressivo_pagamento_seq'::regclass) NOT NULL,
    tipo public.tipo_pagamento NOT NULL,
    data_pagamento timestamp without time zone NOT NULL,
    socio character(16) NOT NULL,
    totale numeric(5,2) NOT NULL,
    CONSTRAINT pagamento_progressivo_check CHECK ((progressivo >= 0)),
    CONSTRAINT pagamento_totale_check CHECK ((totale >= (0)::numeric))
);


ALTER TABLE public.pagamento OWNER TO detognieli;

--
-- Name: pagamento_corso; Type: TABLE; Schema: public; Owner: detognieli
--

CREATE TABLE public.pagamento_corso (
    pagamento integer NOT NULL,
    corso character varying(48) NOT NULL,
    anno_corso integer NOT NULL
);


ALTER TABLE public.pagamento_corso OWNER TO detognieli;

--
-- Name: socio; Type: TABLE; Schema: public; Owner: detognieli
--

CREATE TABLE public.socio (
    cf character(16) NOT NULL,
    nome character varying(48) NOT NULL,
    cognome character varying(48) NOT NULL,
    data_nascita date NOT NULL,
    luogo_nascita character varying(48),
    indirizzo character varying(64),
    conoscenza_scuola public.mod_conoscenza_scuola DEFAULT NULL::character varying
);


ALTER TABLE public.socio OWNER TO detognieli;

--
-- Name: pagamenti_corsi_view; Type: VIEW; Schema: public; Owner: detognieli
--

CREATE VIEW public.pagamenti_corsi_view AS
 SELECT s.cf AS cf_socio,
    s.nome AS nome_socio,
    s.cognome AS cognome_socio,
    pc.corso AS nome_corso,
    pc.anno_corso,
    p.progressivo AS progressivo_pagamento,
    p.totale,
    p.data_pagamento
   FROM ((public.pagamento p
     JOIN public.pagamento_corso pc ON ((p.progressivo = pc.pagamento)))
     JOIN public.socio s ON ((p.socio = s.cf)));


ALTER TABLE public.pagamenti_corsi_view OWNER TO detognieli;

--
-- Name: pagamento_oggetto; Type: TABLE; Schema: public; Owner: detognieli
--

CREATE TABLE public.pagamento_oggetto (
    pagamento integer NOT NULL,
    oggetto integer NOT NULL
);


ALTER TABLE public.pagamento_oggetto OWNER TO detognieli;

--
-- Name: pagamenti_oggetti_view; Type: VIEW; Schema: public; Owner: detognieli
--

CREATE VIEW public.pagamenti_oggetti_view AS
 SELECT p.socio AS cf_socio,
    s.nome AS nome_socio,
    s.cognome AS cognome_socio,
    po.oggetto AS codice_oggetto,
    o.tipo AS tipo_oggetto,
    p.totale,
    p.data_pagamento
   FROM (((public.pagamento p
     JOIN public.pagamento_oggetto po ON ((p.progressivo = po.pagamento)))
     JOIN public.socio s ON ((p.socio = s.cf)))
     JOIN public.oggetto o ON ((po.oggetto = o.codice)));


ALTER TABLE public.pagamenti_oggetti_view OWNER TO detognieli;

--
-- Name: pagamento_tessera; Type: TABLE; Schema: public; Owner: detognieli
--

CREATE TABLE public.pagamento_tessera (
    pagamento integer NOT NULL,
    tessera integer NOT NULL
);


ALTER TABLE public.pagamento_tessera OWNER TO detognieli;

--
-- Name: pagamenti_tessere_view; Type: VIEW; Schema: public; Owner: detognieli
--

CREATE VIEW public.pagamenti_tessere_view AS
 SELECT s.cf AS cf_socio,
    s.nome AS nome_socio,
    s.cognome AS cognome_socio,
    pt.tessera AS codice_tessera,
    p.progressivo AS progressivo_pagamento,
    p.totale,
    p.data_pagamento
   FROM ((public.pagamento_tessera pt
     JOIN public.pagamento p ON ((pt.pagamento = p.progressivo)))
     JOIN public.socio s ON ((p.socio = s.cf)));


ALTER TABLE public.pagamenti_tessere_view OWNER TO detognieli;

--
-- Name: soci_morosi_view; Type: VIEW; Schema: public; Owner: detognieli
--

CREATE VIEW public.soci_morosi_view AS
 SELECT s.cf AS cf_socio,
    s.nome AS nome_socio,
    s.cognome AS cognome_socio,
    i.corso AS nome_corso,
    i.anno_corso
   FROM (public.iscrizione_corso i
     JOIN public.socio s ON ((i.socio = s.cf)))
  WHERE (NOT (EXISTS ( SELECT p.cf_socio,
            p.nome_corso,
            p.anno_corso
           FROM public.pagamenti_corsi_view p
          WHERE ((i.socio = p.cf_socio) AND ((i.corso)::text = (p.nome_corso)::text) AND (i.anno_corso = p.anno_corso)))));


ALTER TABLE public.soci_morosi_view OWNER TO detognieli;

--
-- Name: socio_attivo; Type: TABLE; Schema: public; Owner: detognieli
--

CREATE TABLE public.socio_attivo (
    socio character(16) NOT NULL,
    anno integer NOT NULL,
    tipo public.tipo_socio NOT NULL,
    data_iscrizione date NOT NULL,
    gdpr boolean DEFAULT true NOT NULL,
    discipline character varying(128)
);


ALTER TABLE public.socio_attivo OWNER TO detognieli;

--
-- Name: tessera; Type: TABLE; Schema: public; Owner: detognieli
--

CREATE TABLE public.tessera (
    codice integer NOT NULL,
    socio character(16),
    tipologia public.tipologia_tessera NOT NULL,
    data_scadenza date NOT NULL,
    CONSTRAINT tessera_codice_check CHECK ((codice >= 0))
);


ALTER TABLE public.tessera OWNER TO detognieli;

--
-- Name: tutore; Type: TABLE; Schema: public; Owner: detognieli
--

CREATE TABLE public.tutore (
    cf character(16) NOT NULL,
    nome character varying(48) NOT NULL,
    cognome character varying(48) NOT NULL,
    data_nascita date NOT NULL,
    luogo_nascita character varying(48),
    indirizzo character varying(64)
);


ALTER TABLE public.tutore OWNER TO detognieli;

--
-- Data for Name: appello; Type: TABLE DATA; Schema: public; Owner: detognieli
--

COPY public.appello (data_lezione, corso, anno_corso, presente, socio, anno_socio) FROM stdin;
\.
COPY public.appello (data_lezione, corso, anno_corso, presente, socio, anno_socio) FROM '$$PATH$$/3879.dat';

--
-- Data for Name: aula; Type: TABLE DATA; Schema: public; Owner: detognieli
--

COPY public.aula (numero, nome, capienza, descrizione) FROM stdin;
\.
COPY public.aula (numero, nome, capienza, descrizione) FROM '$$PATH$$/3874.dat';

--
-- Data for Name: certificato_medico; Type: TABLE DATA; Schema: public; Owner: detognieli
--

COPY public.certificato_medico (socio, data_scadenza) FROM stdin;
\.
COPY public.certificato_medico (socio, data_scadenza) FROM '$$PATH$$/3875.dat';

--
-- Data for Name: corso; Type: TABLE DATA; Schema: public; Owner: detognieli
--

COPY public.corso (nome, anno, costo_lezione, livello, descrizione) FROM stdin;
\.
COPY public.corso (nome, anno, costo_lezione, livello, descrizione) FROM '$$PATH$$/3876.dat';

--
-- Data for Name: garante; Type: TABLE DATA; Schema: public; Owner: detognieli
--

COPY public.garante (tutore, anno) FROM stdin;
\.
COPY public.garante (tutore, anno) FROM '$$PATH$$/3880.dat';

--
-- Data for Name: garante_socio; Type: TABLE DATA; Schema: public; Owner: detognieli
--

COPY public.garante_socio (tutore, anno, socio) FROM stdin;
\.
COPY public.garante_socio (tutore, anno, socio) FROM '$$PATH$$/3881.dat';

--
-- Data for Name: insegna; Type: TABLE DATA; Schema: public; Owner: detognieli
--

COPY public.insegna (data_lezione, corso, anno_corso, socio, anno_socio) FROM stdin;
\.
COPY public.insegna (data_lezione, corso, anno_corso, socio, anno_socio) FROM '$$PATH$$/3882.dat';

--
-- Data for Name: iscrizione_corso; Type: TABLE DATA; Schema: public; Owner: detognieli
--

COPY public.iscrizione_corso (corso, anno_corso, socio, anno_socio, data_iscrizione) FROM stdin;
\.
COPY public.iscrizione_corso (corso, anno_corso, socio, anno_socio, data_iscrizione) FROM '$$PATH$$/3883.dat';

--
-- Data for Name: lezione; Type: TABLE DATA; Schema: public; Owner: detognieli
--

COPY public.lezione (corso, anno_corso, data_lezione, aula) FROM stdin;
\.
COPY public.lezione (corso, anno_corso, data_lezione, aula) FROM '$$PATH$$/3877.dat';

--
-- Data for Name: oggetto; Type: TABLE DATA; Schema: public; Owner: detognieli
--

COPY public.oggetto (codice, tipo, prezzo, descrizione, tipo_capo, codice_posto, anno_dvd) FROM stdin;
\.
COPY public.oggetto (codice, tipo, prezzo, descrizione, tipo_capo, codice_posto, anno_dvd) FROM '$$PATH$$/3885.dat';

--
-- Data for Name: pagamento; Type: TABLE DATA; Schema: public; Owner: detognieli
--

COPY public.pagamento (progressivo, tipo, data_pagamento, socio, totale) FROM stdin;
\.
COPY public.pagamento (progressivo, tipo, data_pagamento, socio, totale) FROM '$$PATH$$/3887.dat';

--
-- Data for Name: pagamento_corso; Type: TABLE DATA; Schema: public; Owner: detognieli
--

COPY public.pagamento_corso (pagamento, corso, anno_corso) FROM stdin;
\.
COPY public.pagamento_corso (pagamento, corso, anno_corso) FROM '$$PATH$$/3888.dat';

--
-- Data for Name: pagamento_oggetto; Type: TABLE DATA; Schema: public; Owner: detognieli
--

COPY public.pagamento_oggetto (pagamento, oggetto) FROM stdin;
\.
COPY public.pagamento_oggetto (pagamento, oggetto) FROM '$$PATH$$/3889.dat';

--
-- Data for Name: pagamento_tessera; Type: TABLE DATA; Schema: public; Owner: detognieli
--

COPY public.pagamento_tessera (pagamento, tessera) FROM stdin;
\.
COPY public.pagamento_tessera (pagamento, tessera) FROM '$$PATH$$/3890.dat';

--
-- Data for Name: socio; Type: TABLE DATA; Schema: public; Owner: detognieli
--

COPY public.socio (cf, nome, cognome, data_nascita, luogo_nascita, indirizzo, conoscenza_scuola) FROM stdin;
\.
COPY public.socio (cf, nome, cognome, data_nascita, luogo_nascita, indirizzo, conoscenza_scuola) FROM '$$PATH$$/3871.dat';

--
-- Data for Name: socio_attivo; Type: TABLE DATA; Schema: public; Owner: detognieli
--

COPY public.socio_attivo (socio, anno, tipo, data_iscrizione, gdpr, discipline) FROM stdin;
\.
COPY public.socio_attivo (socio, anno, tipo, data_iscrizione, gdpr, discipline) FROM '$$PATH$$/3873.dat';

--
-- Data for Name: tessera; Type: TABLE DATA; Schema: public; Owner: detognieli
--

COPY public.tessera (codice, socio, tipologia, data_scadenza) FROM stdin;
\.
COPY public.tessera (codice, socio, tipologia, data_scadenza) FROM '$$PATH$$/3872.dat';

--
-- Data for Name: tutore; Type: TABLE DATA; Schema: public; Owner: detognieli
--

COPY public.tutore (cf, nome, cognome, data_nascita, luogo_nascita, indirizzo) FROM stdin;
\.
COPY public.tutore (cf, nome, cognome, data_nascita, luogo_nascita, indirizzo) FROM '$$PATH$$/3878.dat';

--
-- Name: codice_oggetto_seq; Type: SEQUENCE SET; Schema: public; Owner: detognieli
--

SELECT pg_catalog.setval('public.codice_oggetto_seq', 0, false);


--
-- Name: progressivo_pagamento_seq; Type: SEQUENCE SET; Schema: public; Owner: detognieli
--

SELECT pg_catalog.setval('public.progressivo_pagamento_seq', 0, false);


--
-- Name: appello appello_pkey; Type: CONSTRAINT; Schema: public; Owner: detognieli
--

ALTER TABLE ONLY public.appello
    ADD CONSTRAINT appello_pkey PRIMARY KEY (data_lezione, corso, anno_corso, socio, anno_socio);


--
-- Name: aula aula_pkey; Type: CONSTRAINT; Schema: public; Owner: detognieli
--

ALTER TABLE ONLY public.aula
    ADD CONSTRAINT aula_pkey PRIMARY KEY (numero);


--
-- Name: certificato_medico certificato_medico_pkey; Type: CONSTRAINT; Schema: public; Owner: detognieli
--

ALTER TABLE ONLY public.certificato_medico
    ADD CONSTRAINT certificato_medico_pkey PRIMARY KEY (socio, data_scadenza);


--
-- Name: corso corso_pkey; Type: CONSTRAINT; Schema: public; Owner: detognieli
--

ALTER TABLE ONLY public.corso
    ADD CONSTRAINT corso_pkey PRIMARY KEY (nome, anno);


--
-- Name: garante garante_pkey; Type: CONSTRAINT; Schema: public; Owner: detognieli
--

ALTER TABLE ONLY public.garante
    ADD CONSTRAINT garante_pkey PRIMARY KEY (tutore, anno);


--
-- Name: garante_socio garante_socio_pkey; Type: CONSTRAINT; Schema: public; Owner: detognieli
--

ALTER TABLE ONLY public.garante_socio
    ADD CONSTRAINT garante_socio_pkey PRIMARY KEY (tutore, anno);


--
-- Name: insegna insegna_pkey; Type: CONSTRAINT; Schema: public; Owner: detognieli
--

ALTER TABLE ONLY public.insegna
    ADD CONSTRAINT insegna_pkey PRIMARY KEY (data_lezione, corso, anno_corso, socio, anno_socio);


--
-- Name: iscrizione_corso iscrizione_corso_pkey; Type: CONSTRAINT; Schema: public; Owner: detognieli
--

ALTER TABLE ONLY public.iscrizione_corso
    ADD CONSTRAINT iscrizione_corso_pkey PRIMARY KEY (corso, anno_corso, socio, anno_socio);


--
-- Name: lezione lezione_pkey; Type: CONSTRAINT; Schema: public; Owner: detognieli
--

ALTER TABLE ONLY public.lezione
    ADD CONSTRAINT lezione_pkey PRIMARY KEY (corso, anno_corso, data_lezione);


--
-- Name: oggetto oggetto_pkey; Type: CONSTRAINT; Schema: public; Owner: detognieli
--

ALTER TABLE ONLY public.oggetto
    ADD CONSTRAINT oggetto_pkey PRIMARY KEY (codice);


--
-- Name: pagamento_corso pagamento_corso_pkey; Type: CONSTRAINT; Schema: public; Owner: detognieli
--

ALTER TABLE ONLY public.pagamento_corso
    ADD CONSTRAINT pagamento_corso_pkey PRIMARY KEY (pagamento, corso, anno_corso);


--
-- Name: pagamento_oggetto pagamento_oggetto_pkey; Type: CONSTRAINT; Schema: public; Owner: detognieli
--

ALTER TABLE ONLY public.pagamento_oggetto
    ADD CONSTRAINT pagamento_oggetto_pkey PRIMARY KEY (pagamento, oggetto);


--
-- Name: pagamento pagamento_pkey; Type: CONSTRAINT; Schema: public; Owner: detognieli
--

ALTER TABLE ONLY public.pagamento
    ADD CONSTRAINT pagamento_pkey PRIMARY KEY (progressivo);


--
-- Name: pagamento_tessera pagamento_tessera_pkey; Type: CONSTRAINT; Schema: public; Owner: detognieli
--

ALTER TABLE ONLY public.pagamento_tessera
    ADD CONSTRAINT pagamento_tessera_pkey PRIMARY KEY (pagamento, tessera);


--
-- Name: socio_attivo socio_attivo_pkey; Type: CONSTRAINT; Schema: public; Owner: detognieli
--

ALTER TABLE ONLY public.socio_attivo
    ADD CONSTRAINT socio_attivo_pkey PRIMARY KEY (socio, anno);


--
-- Name: socio socio_pkey; Type: CONSTRAINT; Schema: public; Owner: detognieli
--

ALTER TABLE ONLY public.socio
    ADD CONSTRAINT socio_pkey PRIMARY KEY (cf);


--
-- Name: tessera tessera_pkey; Type: CONSTRAINT; Schema: public; Owner: detognieli
--

ALTER TABLE ONLY public.tessera
    ADD CONSTRAINT tessera_pkey PRIMARY KEY (codice);


--
-- Name: tutore tutore_pkey; Type: CONSTRAINT; Schema: public; Owner: detognieli
--

ALTER TABLE ONLY public.tutore
    ADD CONSTRAINT tutore_pkey PRIMARY KEY (cf);


--
-- Name: appello appello_data_lezione_fkey; Type: FK CONSTRAINT; Schema: public; Owner: detognieli
--

ALTER TABLE ONLY public.appello
    ADD CONSTRAINT appello_data_lezione_fkey FOREIGN KEY (data_lezione, corso, anno_corso) REFERENCES public.lezione(data_lezione, corso, anno_corso) ON UPDATE CASCADE;


--
-- Name: appello appello_socio_fkey; Type: FK CONSTRAINT; Schema: public; Owner: detognieli
--

ALTER TABLE ONLY public.appello
    ADD CONSTRAINT appello_socio_fkey FOREIGN KEY (socio, anno_socio) REFERENCES public.socio_attivo(socio, anno) ON UPDATE CASCADE;


--
-- Name: certificato_medico certificato_medico_socio_fkey; Type: FK CONSTRAINT; Schema: public; Owner: detognieli
--

ALTER TABLE ONLY public.certificato_medico
    ADD CONSTRAINT certificato_medico_socio_fkey FOREIGN KEY (socio) REFERENCES public.socio(cf) ON UPDATE CASCADE;


--
-- Name: garante_socio garante_socio_socio_fkey; Type: FK CONSTRAINT; Schema: public; Owner: detognieli
--

ALTER TABLE ONLY public.garante_socio
    ADD CONSTRAINT garante_socio_socio_fkey FOREIGN KEY (socio) REFERENCES public.socio(cf) ON UPDATE CASCADE;


--
-- Name: garante_socio garante_socio_tutore_fkey; Type: FK CONSTRAINT; Schema: public; Owner: detognieli
--

ALTER TABLE ONLY public.garante_socio
    ADD CONSTRAINT garante_socio_tutore_fkey FOREIGN KEY (tutore, anno) REFERENCES public.garante(tutore, anno) ON UPDATE CASCADE;


--
-- Name: garante garante_tutore_fkey; Type: FK CONSTRAINT; Schema: public; Owner: detognieli
--

ALTER TABLE ONLY public.garante
    ADD CONSTRAINT garante_tutore_fkey FOREIGN KEY (tutore) REFERENCES public.tutore(cf) ON UPDATE CASCADE;


--
-- Name: insegna insegna_data_lezione_fkey; Type: FK CONSTRAINT; Schema: public; Owner: detognieli
--

ALTER TABLE ONLY public.insegna
    ADD CONSTRAINT insegna_data_lezione_fkey FOREIGN KEY (data_lezione, corso, anno_corso) REFERENCES public.lezione(data_lezione, corso, anno_corso) ON UPDATE CASCADE;


--
-- Name: insegna insegna_socio_fkey; Type: FK CONSTRAINT; Schema: public; Owner: detognieli
--

ALTER TABLE ONLY public.insegna
    ADD CONSTRAINT insegna_socio_fkey FOREIGN KEY (socio, anno_socio) REFERENCES public.socio_attivo(socio, anno) ON UPDATE CASCADE;


--
-- Name: iscrizione_corso iscrizione_corso_corso_fkey; Type: FK CONSTRAINT; Schema: public; Owner: detognieli
--

ALTER TABLE ONLY public.iscrizione_corso
    ADD CONSTRAINT iscrizione_corso_corso_fkey FOREIGN KEY (corso, anno_corso) REFERENCES public.corso(nome, anno) ON UPDATE CASCADE;


--
-- Name: iscrizione_corso iscrizione_corso_socio_fkey; Type: FK CONSTRAINT; Schema: public; Owner: detognieli
--

ALTER TABLE ONLY public.iscrizione_corso
    ADD CONSTRAINT iscrizione_corso_socio_fkey FOREIGN KEY (socio, anno_socio) REFERENCES public.socio_attivo(socio, anno) ON UPDATE CASCADE;


--
-- Name: lezione lezione_aula_fkey; Type: FK CONSTRAINT; Schema: public; Owner: detognieli
--

ALTER TABLE ONLY public.lezione
    ADD CONSTRAINT lezione_aula_fkey FOREIGN KEY (aula) REFERENCES public.aula(numero) ON UPDATE CASCADE;


--
-- Name: lezione lezione_corso_fkey; Type: FK CONSTRAINT; Schema: public; Owner: detognieli
--

ALTER TABLE ONLY public.lezione
    ADD CONSTRAINT lezione_corso_fkey FOREIGN KEY (corso, anno_corso) REFERENCES public.corso(nome, anno) ON UPDATE CASCADE;


--
-- Name: pagamento_corso pagamento_corso_corso_fkey; Type: FK CONSTRAINT; Schema: public; Owner: detognieli
--

ALTER TABLE ONLY public.pagamento_corso
    ADD CONSTRAINT pagamento_corso_corso_fkey FOREIGN KEY (corso, anno_corso) REFERENCES public.corso(nome, anno) ON UPDATE CASCADE;


--
-- Name: pagamento_corso pagamento_corso_pagamento_fkey; Type: FK CONSTRAINT; Schema: public; Owner: detognieli
--

ALTER TABLE ONLY public.pagamento_corso
    ADD CONSTRAINT pagamento_corso_pagamento_fkey FOREIGN KEY (pagamento) REFERENCES public.pagamento(progressivo) ON UPDATE CASCADE;


--
-- Name: pagamento_oggetto pagamento_oggetto_oggetto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: detognieli
--

ALTER TABLE ONLY public.pagamento_oggetto
    ADD CONSTRAINT pagamento_oggetto_oggetto_fkey FOREIGN KEY (oggetto) REFERENCES public.oggetto(codice) ON UPDATE CASCADE;


--
-- Name: pagamento_oggetto pagamento_oggetto_pagamento_fkey; Type: FK CONSTRAINT; Schema: public; Owner: detognieli
--

ALTER TABLE ONLY public.pagamento_oggetto
    ADD CONSTRAINT pagamento_oggetto_pagamento_fkey FOREIGN KEY (pagamento) REFERENCES public.pagamento(progressivo) ON UPDATE CASCADE;


--
-- Name: pagamento pagamento_socio_fkey; Type: FK CONSTRAINT; Schema: public; Owner: detognieli
--

ALTER TABLE ONLY public.pagamento
    ADD CONSTRAINT pagamento_socio_fkey FOREIGN KEY (socio) REFERENCES public.socio(cf) ON UPDATE CASCADE;


--
-- Name: pagamento_tessera pagamento_tessera_pagamento_fkey; Type: FK CONSTRAINT; Schema: public; Owner: detognieli
--

ALTER TABLE ONLY public.pagamento_tessera
    ADD CONSTRAINT pagamento_tessera_pagamento_fkey FOREIGN KEY (pagamento) REFERENCES public.pagamento(progressivo) ON UPDATE CASCADE;


--
-- Name: pagamento_tessera pagamento_tessera_tessera_fkey; Type: FK CONSTRAINT; Schema: public; Owner: detognieli
--

ALTER TABLE ONLY public.pagamento_tessera
    ADD CONSTRAINT pagamento_tessera_tessera_fkey FOREIGN KEY (tessera) REFERENCES public.tessera(codice) ON UPDATE CASCADE;


--
-- Name: socio_attivo socio_attivo_socio_fkey; Type: FK CONSTRAINT; Schema: public; Owner: detognieli
--

ALTER TABLE ONLY public.socio_attivo
    ADD CONSTRAINT socio_attivo_socio_fkey FOREIGN KEY (socio) REFERENCES public.socio(cf) ON UPDATE CASCADE;


--
-- Name: tessera tessera_socio_fkey; Type: FK CONSTRAINT; Schema: public; Owner: detognieli
--

ALTER TABLE ONLY public.tessera
    ADD CONSTRAINT tessera_socio_fkey FOREIGN KEY (socio) REFERENCES public.socio(cf) ON UPDATE CASCADE;


--
-- PostgreSQL database dump complete
--

